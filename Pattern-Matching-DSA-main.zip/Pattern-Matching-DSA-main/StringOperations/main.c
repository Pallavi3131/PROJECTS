#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<stdbool.h>
#include"trie.h"

int main(int argv, char* argc[]){
    trie t;
    int line;
    char s[100];
    char *prefix;


    if(argv == 1){
        printf("Error : Enter valid flag\n");
        help();
        return 0;
    }

    //Lexicographical display : -d data.txt
    if(strcmp(argc[1], "-d")==0){
        if(argv == 2){
            printf("Invalid : Filename missing\n");
            return 0;
        }
        initTrie(&t, argc[2]);
        FILE *f = fopen(argc[2], "w");
        if(f == NULL)
            return 0;
        sortTrie(t, s, 0, f);
        fclose(f);
    }


    //Search Word : -s data.txt good
    if(strcmp(argc[1], "-s")==0){
        if(argv <= 3){
            printf("Invalid : very few arguments\n");
            return 0;
        }
        initTrie(&t, argc[2]);
        if(searchTrie(t, argc[3], &line))
            printf("%s Found at line %d\n", argc[3], line);
        else
            printf("Not Found\n");
    }


    //Longest prefix : -l data.txt
    if(strcmp(argc[1], "-l")==0){
        if(argv == 2){
            printf("Invalid : Filename missing\n");
            return 0;
        }
        initTrie(&t, argc[2]);
        prefix = longestPrefix(t);
        printf("Longest common prefix : %s\n", prefix);
    }



    //Occurrence of Word : -o data.txt game
    if(strcmp(argc[1], "-o")==0){
        if(argv <= 3){
            printf("Invalid : very few arguments\n");
            return 0;
        }
        initTrie(&t, argc[2]);
        int count = countOccurance(t, argc[3], &line);
        if(count!=0){
            printf("%d times\n", count);
            printf("Last occurrence at line %d\n", line);
        }
        else
            printf("Not Found\n");
    }


    //Kprefix: -k data.txt good 2
    if(strcmp(argc[1], "-k")==0){
        if(argv <= 4){
            printf("Invalid : very few arguments\n");
            return 0;
        }
        initTrie(&t, argc[2]);
        int k = atoi(argc[4]);
        int count = kPrefix(t, argc[3], k);
        printf("count : %d\n", count);
    }


    //Prefix Search : -p data.txt go
    if(strcmp(argc[1], "-p")==0){
        if(argv <= 3){
            printf("Invalid : very few arguments\n");
            return 0;
        }
        initTrie(&t, argc[2]);
        if(prefixSearch(t, argc[3])==0)
            printf("Not Found\n");
    }


    //Shortest prefix : -x info.txt
    if(strcmp(argc[1], "-x")==0){
        if(argv == 2){
            printf("Invalid : Filename missing\n");
            return 0;
        }
        initTrie(&t, argc[2]);
        shortestPrefix(t, s, 0);
    }

    //Help : -h
    if(strcmp(argc[1], "-h")==0){
        help();
        return 0;
    }

    return 0;
}
