#include<stdio.h>
#include<stdlib.h>
#include<stdbool.h>
#include<string.h>
#include"trie.h"


void printWords(trie t, char prefix[]);

//Create a node in trie
node* createNode(){
    node* nn = (node*) malloc(sizeof(node));
    if(!nn)
        return NULL;
    nn->endW = false;
    nn->counts = 0;
    nn->prefixCount = 0;
    nn->line_no = 0;
    for(int i=0;i<26;i++){
        nn->next[i] = NULL;
    }
    return nn;
}

//Initialize trie data structure and populate by the file provided
void initTrie(trie *t, char *filename){
    int line = 0;
    *t = createNode();
    char input[100];
    FILE *f = fopen(filename, "r");
    if(f == NULL)
        return;
    while(fscanf(f, "%s", input)==1){
        line++;
        insertTrie(t, input, line);
    }
    return;
}

//Insert strings in the trie
void insertTrie(trie *t, char* s, int line){
    int len = strlen(s);
    node *p = *t;
    for(int i=0;i<len;i++){
        if(p->next[s[i] - 'a'] == NULL)
            p->next[s[i] - 'a'] = createNode();

        p->next[s[i] - 'a']->prefixCount++;
        p = p->next[s[i] - 'a'];
    }
    p->endW = true;
    p->line_no = line;
    p->data = s;
    //printf("%s\n", p->data);
    p->counts += 1;
    return;
}


//Search a string into trie
bool searchTrie(trie t, char* s, int *line){
    node *p = t;
    int len = strlen(s);
    for(int i=0;i<len;i++){
        if(p->next[s[i] - 'a'] == NULL)
            return false;
        p = p->next[s[i] - 'a'];
    }
    *line = p->line_no;
    return p->endW;
}


//Count no of children of given node
int countChildren(trie t, int *pos){
    int count=0;
    node *p = t;
    for(int i=0; i<26; i++){
        if(p->next[i] != NULL){
            count++;
            *pos = i;
        }
    }
    return count;
}


//Find longest common prefix from all strings
char* longestPrefix(trie t){
    node *p = t;
    static char prefix[50] = "";
    int pos = 0;
    char str[10];
    while(countChildren(p, &pos)==1 && p->endW == false){
        char ch = pos + 'a';
        str[0] = ch;
        str[1] = '\0';
        strcat(prefix, str);
        p = p->next[pos];
    }
    return prefix;
}

//Count occurrences of given string in trie
int countOccurance(trie t, char* s, int *line){
    node *p = t;
    int len = strlen(s);
    for(int i=0;i<len;i++){
        if(p->next[s[i] - 'a'] == NULL)
            return false;
        p = p->next[s[i] - 'a'];
    }
    *line = p->line_no;
    return p->counts;
}


//count no of strings having K length common prefix
int kPrefix(trie t, char* pattern, int k){
    int pos, count = 0;
    node *p = t;
    int words = 0;
    for(int i=0; i<strlen(pattern); i++){
        pos = pattern[i] - 'a';

        if(p->next[pos] == NULL){
            break;
        }
        p = p->next[pos];
        count++;

        if(count == k){
            words = p->prefixCount;
        }
    }
    return words;
}


//find shortest unique prefix of strings
void shortestPrefix(trie t, char prefixes[], int pos){
    if(t == NULL)
        return;

    if(t->prefixCount == 1){
        prefixes[pos] = '\0';
        printf("%s\n", prefixes);
        return;
    }

    for(int i=0; i<26; i++){
        if(t->next[i]){
            prefixes[pos] = i + 'a';
            shortestPrefix(t->next[i], prefixes, pos+1);
        }
    }
    return;
}


//checking end of word
bool isEnd(trie root){
    for(int i = 0; i < 26; i++)
        if (root->next[i])
            return false;
    return true;
}


//printing words with particular prefix
void printWords(trie t, char prefix[]){
    char str[50],p[50];
    strcpy(p, prefix);
    char c;
    if(t->endW)
        printf("%d %s\n", t->line_no, prefix);

    if(isEnd(t))
        return;

    for(int i=0; i<26; i++){
        if(t->next[i]){
            strcpy(p, prefix);
            c = i + 'a';
            str[0] = c;
            str[1] = '\0';
            strcat(p, str);
            printWords(t->next[i], p);
            strcpy(p, " ");
        }
    }
    return;
}

//prefix search
int prefixSearch(trie t, char pattern[]){
    node *p = t;
    int len = strlen(pattern);
    for(int i=0; i<len; i++){
        int pos = pattern[i] - 'a';
        if(!p->next[pos])
            return 0;
        p = p->next[pos];
    }
    printWords(p, pattern);
    return 1;
}

//Lexicographical sorting of strings
void sortTrie(trie t, char word[], int pos, FILE *f){
    if(t->endW == true){
        word[pos] = '\0';
        fprintf(f, "%s\n", word);
    }
    for(int i=0;i<26;i++){
        if(t->next[i]){
            word[pos] = i + 'a';
            sortTrie(t->next[i], word, pos+1, f);
        }
    }
    return;
}

//help function
void help(){
    printf("-s : Search Word\n");
    printf("-l : Longest prefix\n");
    printf("-x : Shortest prefix\n");
    printf("-k : K length prefix\n");
    printf("-p : Prefix Search\n");
    printf("-o : Occurrence of Word\n");
    printf("-d : Lexicographical display\n");
    return;
}
