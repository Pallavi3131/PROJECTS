#ifndef TRIE_H_INCLUDED
#define TRIE_H_INCLUDED

//ADT structure for Trie
typedef struct node{
    char *data;
    bool endW;
    int prefixCount;
    int counts;
    int line_no;
    struct node* next[26];
}node;

typedef node* trie;

//Functionalities Provided
void initTrie(trie *t, char *filename);
void insertTrie(trie *t, char* s,int line);
bool searchTrie(trie t, char* s, int* line);
char* longestPrefix(trie t);
int countOccurance(trie t, char* s, int *line);
int kPrefix(trie t, char* pattern, int k);
void shortestPrefix(trie t, char prefixes[],int pos);
int prefixSearch(trie t, char str[]);
void sortTrie(trie t, char word[], int pos, FILE *f);
void help();


#endif // TRIE_H_INCLUDED
