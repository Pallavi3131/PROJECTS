#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<stdbool.h>
#include"trie.h"

int
main (int argv)
{
  trie t;
  int line;
  char s[100];
  char *prefix;

  char *filename = "info.txt";
  char *filename1 = "data.txt";

  int choice;

  printf ("\n*** PATTERN MATCHING-TRIE ****\n\n");
  while (choice != 6)
    {

      printf ("Select any option you want:\n");
      printf ("1. Search \n"
	      "2. Lexicographical sort\n"
	      "3. Longest common prefix\n"
	      "4. occurance of word\n" "5. Shortest Unique Prefix\n");
      scanf ("%d", &choice);

      switch (choice)
	{
	case 1:		//search
	  initTrie (&t, filename);
	  char string[100];
	  printf ("Enter the word you want to search for :\n");
	  scanf ("%s", string);
	  if (searchTrie (t, string, &line))
	    printf ("%s Found at line %d\n", string, line);
	  else
	    printf ("Not Found\n");

	  break;
	case 2:		//alphabetically sorted
	  initTrie (&t, filename1);
	  FILE *f = fopen (filename1, "w");
	  if (f == NULL)
	    return 0;
	  sortTrie (t, s, 0, f);
	  fclose (f);
	  printf ("The file has been sorted!\n");
	  break;
	case 3:		//longest common prefix
	  initTrie (&t, filename1);
	  prefix = longestPrefix (t);
	  printf ("Longest common prefix : %s\n", prefix);
	  break;
	case 4:		//Occurrence
	  initTrie (&t, filename1);
	  char string1[100];
	  printf ("Enter the word you want to find occurance for :");
	  scanf ("%s", string1);
	  printf ("%s\n", string1);
	  int count = countOccurance (t, string1, &line);
	  if (count != 0)
	    {
	      printf ("Occured %d times\n", count);
	      printf ("Last occurrence at line %d\n", line);
	    }
	  else
	    printf ("Not Found\n");
	  break;
	case 5:		// shortest unique prefix
	  initTrie (&t, filename1);
	  shortestPrefix (t, s, 0);
	  printf ("Shortest Unique Prefix : %s\n", prefix);
	  break;

	}
    }


  return 0;
}